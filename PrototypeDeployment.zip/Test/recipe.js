document.addEventListener('DOMContentLoaded', function() {
    // Get recipe data from localStorage if it exists
    const recipeData = JSON.parse(localStorage.getItem('currentRecipe')) || {
        name: '',
        description: '',
        prepTime: '',
        cookTime: '',
        servings: '',
        ingredients: [],
        instructions: [],
        notes: ''
    };

    // Initialize form with recipe data
    initializeForm(recipeData);

    // Add event listeners
    document.getElementById('addIngredient').addEventListener('click', addIngredient);
    document.getElementById('addInstruction').addEventListener('click', addInstruction);
    document.getElementById('saveRecipe').addEventListener('click', saveRecipe);
    document.getElementById('previewRecipe').addEventListener('click', previewRecipe);
});

function initializeForm(recipe) {
    document.getElementById('recipeName').value = recipe.name;
    document.getElementById('recipeDescription').value = recipe.description;
    document.getElementById('prepTime').value = recipe.prepTime;
    document.getElementById('cookTime').value = recipe.cookTime;
    document.getElementById('servings').value = recipe.servings;
    document.getElementById('notes').value = recipe.notes;

    // Initialize ingredients
    const ingredientsList = document.getElementById('ingredientsList');
    ingredientsList.innerHTML = '';
    if (recipe.ingredients.length > 0) {
        recipe.ingredients.forEach(ingredient => addIngredient(ingredient));
    } else {
        addIngredient();
    }

    // Initialize instructions
    const instructionsList = document.getElementById('instructionsList');
    instructionsList.innerHTML = '';
    if (recipe.instructions.length > 0) {
        recipe.instructions.forEach(instruction => addInstruction(instruction));
    } else {
        addInstruction();
    }
}

function addIngredient(value = '') {
    const ingredientsList = document.getElementById('ingredientsList');
    const div = document.createElement('div');
    div.className = 'ingredient-item';
    div.innerHTML = `
        <input type="text" placeholder="Enter ingredient" value="${value}" class="ingredient-input">
        <button type="button" class="remove-btn" onclick="removeItem(this)">
            <i class="fas fa-times"></i>
        </button>
    `;
    ingredientsList.appendChild(div);
}

function addInstruction(value = '') {
    const instructionsList = document.getElementById('instructionsList');
    const div = document.createElement('div');
    div.className = 'instruction-item';
    div.innerHTML = `
        <textarea placeholder="Enter instruction step" class="instruction-input" rows="2">${value}</textarea>
        <button type="button" class="remove-btn" onclick="removeItem(this)">
            <i class="fas fa-times"></i>
        </button>
    `;
    instructionsList.appendChild(div);
}

function removeItem(button) {
    button.parentElement.remove();
}

function saveRecipe() {
    const recipe = {
        name: document.getElementById('recipeName').value,
        description: document.getElementById('recipeDescription').value,
        prepTime: document.getElementById('prepTime').value,
        cookTime: document.getElementById('cookTime').value,
        servings: document.getElementById('servings').value,
        ingredients: Array.from(document.querySelectorAll('.ingredient-input')).map(input => input.value),
        instructions: Array.from(document.querySelectorAll('.instruction-input')).map(input => input.value),
        notes: document.getElementById('notes').value
    };

    localStorage.setItem('currentRecipe', JSON.stringify(recipe));
    alert('Recipe saved successfully!');
}

function previewRecipe() {
    // Save current state
    saveRecipe();
    // Open preview in new tab (you can create a preview.html page later)
    window.open('preview.html', '_blank');
} 