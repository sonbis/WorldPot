const chefs = {
    'chef-maria': {
        name: 'Chef Maria Rodriguez',
        title: 'Asian Fusion Specialist',
        avatar: 'assets/chef1.jpg',
        banner: 'assets/chef-banner1.jpg',
        stats: {
            recipes: 32,
            avgRating: 4.9,
            totalLikes: 15420
        },
        bio: 'Chef Maria Rodriguez is an award-winning chef known for her innovative fusion of Asian and Mediterranean cuisines. With over 15 years of culinary experience, she has revolutionized the way we think about cross-cultural cooking. After training in both Tokyo and Barcelona, Maria developed her unique style that respects traditional techniques while embracing modern innovation.',
        specialties: [
            { name: 'Asian Fusion', icon: '🍜' },
            { name: 'Mediterranean', icon: '🫒' },
            { name: 'Seafood', icon: '🐟' }
        ],
        achievements: [
            { title: 'Best Chef 2023', description: 'Culinary Institute of America' },
            { title: 'Innovation Award', description: 'International Food Festival' },
            { title: 'Master Chef', description: '3-Star Restaurant Experience' }
        ],
        featuredRecipes: [
            {
                title: 'Thai Pizza',
                image: 'assets/recipe2.jpg',
                rating: '4.9',
                likes: '312'
            },
            // Add more recipes
        ]
    },
    'chef-alex': {
        name: 'Chef Alex Chen',
        title: 'Mediterranean Expert',
        avatar: 'assets/chef2.jpg',
        banner: 'assets/chef-banner2.jpg',
        stats: {
            recipes: 28,
            avgRating: 4.8,
            totalLikes: 12840
        },
        bio: 'Chef Alex Chen brings Mediterranean cuisine to new heights with his modern interpretations of classic dishes. His journey began in Greece, where he spent five years mastering traditional techniques before bringing his expertise to some of the world\'s most prestigious restaurants.',
        specialties: [
            { name: 'Greek Cuisine', icon: '🫔' },
            { name: 'Italian', icon: '🍝' },
            { name: 'Pastry', icon: '🥐' }
        ],
        achievements: [
            { title: 'Mediterranean Chef of the Year', description: '2022' },
            { title: 'Culinary Excellence', description: 'European Food Awards' },
            { title: 'Best Restaurant', description: 'City Dining Awards 2023' }
        ],
        featuredRecipes: [
            {
                title: 'Mediterranean Sushi',
                image: 'assets/recipe4.jpg',
                rating: '4.6',
                likes: '156'
            },
            // Add more recipes
        ]
    },
    // Add more chefs...
};

// Get chef ID from URL parameter
const urlParams = new URLSearchParams(window.location.search);
const chefId = urlParams.get('chef');

// Load chef content
function loadChefProfile(chefId) {
    const chef = chefs[chefId];
    if (!chef) return;

    document.getElementById('chef-banner').src = chef.banner;
    document.getElementById('chef-avatar').src = chef.avatar;
    document.getElementById('chef-name').textContent = chef.name;
    document.getElementById('chef-title').textContent = chef.title;
    
    document.getElementById('recipe-count').textContent = `🏆 ${chef.stats.recipes} Recipes`;
    document.getElementById('avg-rating').textContent = `⭐ ${chef.stats.avgRating} Avg Rating`;
    document.getElementById('total-likes').textContent = `❤️ ${chef.stats.totalLikes} Likes`;
    
    document.getElementById('chef-bio').textContent = chef.bio;

    const specialtiesList = document.getElementById('specialties-list');
    specialtiesList.innerHTML = chef.specialties
        .map(specialty => `
            <div class="specialty-card">
                <div class="specialty-icon">${specialty.icon}</div>
                <h3>${specialty.name}</h3>
            </div>
        `).join('');

    const achievementsList = document.getElementById('achievements-list');
    achievementsList.innerHTML = chef.achievements
        .map(achievement => `
            <div class="achievement-card">
                <h3>${achievement.title}</h3>
                <p>${achievement.description}</p>
            </div>
        `).join('');

    const recipesGrid = document.getElementById('recipes-grid');
    recipesGrid.innerHTML = chef.featuredRecipes
        .map(recipe => `
            <div class="recipe-card">
                <img src="${recipe.image}" alt="${recipe.title}">
                <div class="recipe-card-content">
                    <h3>${recipe.title}</h3>
                    <div class="recipe-stats">
                        <span>⭐ ${recipe.rating}</span>
                        <span>❤️ ${recipe.likes}</span>
                    </div>
                </div>
            </div>
        `).join('');
}

// Load chef profile when page loads
document.addEventListener('DOMContentLoaded', () => {
    loadChefProfile(chefId);
}); 