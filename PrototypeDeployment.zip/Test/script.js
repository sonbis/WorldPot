// Handle Modal Open/Close
document.addEventListener('DOMContentLoaded', () => {
    const loginModal = document.getElementById('login-modal');
    const signupModal = document.getElementById('signup-modal');
    const closeButtons = document.querySelectorAll('.modal .close');

    document.querySelector('.login').addEventListener('click', () => {
        loginModal.style.display = 'block';
    });

    document.querySelector('.signup').addEventListener('click', () => {
        signupModal.style.display = 'block';
    });

    closeButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            loginModal.style.display = 'none';
            signupModal.style.display = 'none';
        });
    });

    window.addEventListener('click', e => {
        if (e.target === loginModal || e.target === signupModal) {
            loginModal.style.display = 'none';
            signupModal.style.display = 'none';
        }
    });

    // Switch between login and signup
    document.querySelector('.switch-to-signup').addEventListener('click', (e) => {
        e.preventDefault();
        loginModal.style.display = 'none';
        signupModal.style.display = 'block';
    });

    document.querySelector('.switch-to-login').addEventListener('click', (e) => {
        e.preventDefault();
        signupModal.style.display = 'none';
        loginModal.style.display = 'block';
    });

    // Handle file upload in AI Recognition
    const uploadArea = document.querySelector('.upload-area');
    const fileInput = document.getElementById('image-upload');

    uploadArea.addEventListener('click', () => {
        fileInput.click();
    });

    fileInput.addEventListener('change', handleFileUpload);

    // Handle drag and drop
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = '#65c051';
    });

    uploadArea.addEventListener('dragleave', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = '#ddd';
    });

    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        const files = e.dataTransfer.files;
        if (files.length) {
            fileInput.files = files;
            handleFileUpload();
        }
    });

    // Initialize all scroll containers
    const scrollContainers = document.querySelectorAll('.scroll-container');
    
    scrollContainers.forEach(container => {
        const wrapper = container.querySelector('.scroll-wrapper');
        const leftArrow = container.querySelector('.scroll-arrow.left');
        const rightArrow = container.querySelector('.scroll-arrow.right');
        
        // Scroll amount (width of one card plus gap)
        const scrollAmount = container.classList.contains('contributors-grid') ? 424 : 344; // card width + gap
        
        leftArrow.addEventListener('click', () => {
            wrapper.scrollBy({
                left: -scrollAmount,
                behavior: 'smooth'
            });
        });
        
        rightArrow.addEventListener('click', () => {
            wrapper.scrollBy({
                left: scrollAmount,
                behavior: 'smooth'
            });
        });
        
        // Update arrow visibility
        const updateArrows = () => {
            leftArrow.style.opacity = wrapper.scrollLeft <= 0 ? '0.5' : '1';
            rightArrow.style.opacity = 
                wrapper.scrollLeft >= wrapper.scrollWidth - wrapper.clientWidth ? '0.5' : '1';
        };
        
        wrapper.addEventListener('scroll', updateArrows);
        window.addEventListener('resize', updateArrows);
        updateArrows(); // Initial check
    });
});

function handleFileUpload() {
    // Add your image processing logic here
    console.log('File uploaded');
}

// Carousel (Future Development Placeholder)
function initCarousel() {
    console.log('Initialize carousel logic here.');
}

let lastScroll = 0;
const header = document.querySelector('header');

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll <= 0) {
        header.classList.remove('scroll-up');
        return;
    }
    
    if (currentScroll > lastScroll && !header.classList.contains('scroll-down')) {
        // Scrolling down
        header.classList.remove('scroll-up');
        header.classList.add('scroll-down');
    } else if (currentScroll < lastScroll && header.classList.contains('scroll-down')) {
        // Scrolling up
        header.classList.remove('scroll-down');
        header.classList.add('scroll-up');
    }
    
    lastScroll = currentScroll;
});

function checkScrollPosition(wrapper, leftArrow, rightArrow) {
    // Check if scrolling is possible
    const scrollWidth = wrapper.scrollWidth - wrapper.clientWidth;
    
    // Disable left arrow if at start
    leftArrow.disabled = wrapper.scrollLeft <= 0;
    
    // Disable right arrow if at end
    rightArrow.disabled = Math.ceil(wrapper.scrollLeft) >= scrollWidth;
    
    // Add visual feedback
    leftArrow.style.opacity = leftArrow.disabled ? '0.5' : '1';
    rightArrow.style.opacity = rightArrow.disabled ? '0.5' : '1';
}

// Optional: Add keyboard navigation
document.addEventListener('keydown', (e) => {
    const activeContainer = document.querySelector('.scroll-container:hover');
    if (!activeContainer) return;
    
    const wrapper = activeContainer.querySelector('.scroll-wrapper');
    const scrollAmount = 320;
    
    if (e.key === 'ArrowLeft') {
        wrapper.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });
    } else if (e.key === 'ArrowRight') {
        wrapper.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });
    }
});

function handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    // Here you would typically validate with your backend
    // For now, we'll just store in localStorage
    localStorage.setItem('currentUser', JSON.stringify({
        email: email,
        isLoggedIn: true
    }));

    window.location.href = 'profile.html';
    return false;
}

function handleSignup(event) {
    event.preventDefault();
    const name = document.getElementById('signup-name').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;
    const dietaryPreferences = Array.from(document.querySelectorAll('.checkbox-group input:checked'))
        .map(checkbox => checkbox.value);

    // Store user data
    localStorage.setItem('currentUser', JSON.stringify({
        name: name,
        email: email,
        dietaryPreferences: dietaryPreferences,
        isLoggedIn: true
    }));

    window.location.href = 'profile.html';
    return false;
}

// Check login status on page load
document.addEventListener('DOMContentLoaded', function() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const userNav = document.querySelector('.user-profile-nav');
    const ctaButtons = document.querySelector('.cta-buttons');

    if (currentUser && currentUser.isLoggedIn) {
        userNav.style.display = 'block';
        ctaButtons.style.display = 'none';
    } else {
        userNav.style.display = 'none';
        ctaButtons.style.display = 'flex';
    }
});
