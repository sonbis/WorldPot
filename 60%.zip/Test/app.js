const express = require('express');
const app = express();
const gamificationRoutes = require('./gamification-api');

app.use(express.json());
app.use('/api', gamificationRoutes);

// ... rest of your server code ... 